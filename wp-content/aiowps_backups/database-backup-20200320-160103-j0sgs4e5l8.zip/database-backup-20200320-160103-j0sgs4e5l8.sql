-- All In One WP Security & Firewall 4.4.3
-- MySQL dump
-- 2020-03-20 08:01:03

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=4350 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://www.simonchen.cn","yes");
INSERT INTO `wp_options` VALUES("2","home","http://www.simonchen.cn","yes");
INSERT INTO `wp_options` VALUES("3","blogname","墨说有话","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","SimonChen‘s Blog","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","2545229027@qq.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","1","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","closed","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","closed","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","Y年n月j日","yes");
INSERT INTO `wp_options` VALUES("24","time_format","ag:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","Y年n月j日ag:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("29","rewrite_rules","a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:4:{i:0;s:37:\"wp-hide-security-enhancer/wp-hide.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:33:\"classic-editor/classic-editor.php\";i:3;s:29:\"health-check/health-check.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","minimal-portfolio","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","minimal-portfolio","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","45805","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:7:\"Catalog\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:3:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;i:3;a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:1:{s:33:\"classic-editor/classic-editor.php\";a:2:{i:0;s:14:\"Classic_Editor\";i:1;s:9:\"uninstall\";}}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","Asia/Shanghai","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","8","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("93","initial_db_version","44719","yes");
INSERT INTO `wp_options` VALUES("94","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("95","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("96","WPLANG","zh_CN","yes");
INSERT INTO `wp_options` VALUES("97","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","sidebars_widgets","a:7:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:13:\"custom_html-3\";i:3;s:5:\"rss-3\";i:4;s:14:\"recent-posts-2\";i:5;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:11:\"tag_cloud-3\";i:2;s:13:\"custom_html-5\";}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("103","cron","a:8:{i:1584693347;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1584693397;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1584693398;a:4:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1584693406;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1584693413;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1584776147;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1585125592;a:1:{s:40:\"health-check-scheduled-site-status-check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_audio","a:2:{s:12:\"_multiwidget\";i:1;i:3;a:10:{s:7:\"preload\";s:4:\"none\";s:4:\"loop\";b:0;s:3:\"mp3\";s:87:\"http://www.simonchen.cn/wp-content/uploads/2019/12/中岛美嘉-雪の華-雪之花.mp3\";s:3:\"ogg\";s:0:\"\";s:4:\"flac\";s:0:\"\";s:3:\"m4a\";s:0:\"\";s:3:\"wav\";s:0:\"\";s:13:\"attachment_id\";i:71;s:3:\"url\";s:87:\"http://www.simonchen.cn/wp-content/uploads/2019/12/中岛美嘉-雪の華-雪之花.mp3\";s:5:\"title\";s:5:\"Music\";}}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_image","a:4:{s:12:\"_multiwidget\";i:1;i:3;a:15:{s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:500;s:6:\"height\";i:334;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";s:13:\"attachment_id\";i:11;s:3:\"url\";s:98:\"http://www.simonchen.cn/wp-content/uploads/2019/11/指南针-背景_百度图片搜索-300x200.jpg\";s:5:\"title\";s:0:\"\";}i:4;a:15:{s:4:\"size\";s:9:\"thumbnail\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";s:13:\"attachment_id\";i:8;s:3:\"url\";s:73:\"http://www.simonchen.cn/wp-content/uploads/2019/11/head-Re300-150x150.png\";s:5:\"title\";s:0:\"\";}i:6;a:15:{s:4:\"size\";s:9:\"thumbnail\";s:5:\"width\";i:258;s:6:\"height\";i:258;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";s:13:\"attachment_id\";i:90;s:3:\"url\";s:93:\"http://www.simonchen.cn/wp-content/uploads/2019/12/qrcode_for_gh_99d774cc7790_258-150x150.jpg\";s:5:\"title\";s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_tag_cloud","a:2:{s:12:\"_multiwidget\";i:1;i:3;a:3:{s:5:\"title\";s:4:\"Tags\";s:5:\"count\";i:0;s:8:\"taxonomy\";s:8:\"post_tag\";}}","yes");
INSERT INTO `wp_options` VALUES("111","widget_nav_menu","a:2:{s:12:\"_multiwidget\";i:1;i:3;a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("112","widget_custom_html","a:3:{s:12:\"_multiwidget\";i:1;i:3;a:0:{}i:5;a:2:{s:5:\"title\";s:6:\"WeChat\";s:7:\"content\";s:276:\"<div class=\"lxfs\">
	<style>
		.QR-wechat {
			display: block;
			height:50%;
			width:50%;
			float: left;
			padding-top:0;
		}
	</style>
	<img class=\"QR-wechat\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/12/qrcode_for_gh_99d774cc7790_430.jpg\">
	
</div>\";}}","yes");
INSERT INTO `wp_options` VALUES("114","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("116","theme_mods_twentynineteen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575306897;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("143","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("149","_transient_health-check-site-status-result","{\"good\":\"10\",\"recommended\":\"4\",\"critical\":\"3\"}","yes");
INSERT INTO `wp_options` VALUES("376","current_theme","Minimal Portfolio","yes");
INSERT INTO `wp_options` VALUES("377","theme_mods_online-cv-resume","a:8:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:11:\"custom_logo\";i:8;s:16:\"header_textcolor\";s:5:\"blank\";s:12:\"header_image\";s:68:\"http://www.simonchen.cn/wp-content/uploads/2019/11/JXOCYQZO1192W.jpg\";s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:6;s:3:\"url\";s:68:\"http://www.simonchen.cn/wp-content/uploads/2019/11/JXOCYQZO1192W.jpg\";s:13:\"thumbnail_url\";s:68:\"http://www.simonchen.cn/wp-content/uploads/2019/11/JXOCYQZO1192W.jpg\";s:6:\"height\";i:574;s:5:\"width\";i:860;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575307892;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:4:{i:0;s:8:\"search-2\";i:1;s:10:\"archives-2\";i:2;s:12:\"categories-2\";i:3;s:6:\"meta-2\";}s:4:\"hero\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("378","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("379","online_cv_resume_admin_notice_welcome","1","yes");
INSERT INTO `wp_options` VALUES("387","theme_mods_twentyfifteen","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"social\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575308622;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:3:{i:0;s:5:\"rss-3\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:2:{i:0;s:8:\"search-2\";i:1;s:12:\"categories-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("394","theme_mods_catch-vogue","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:6:\"menu-1\";i:2;s:13:\"social-footer\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575309173;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:13:\"custom_html-3\";i:3;s:5:\"rss-3\";i:4;s:14:\"recent-posts-2\";i:5;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:2:{i:0;s:8:\"search-2\";i:1;s:12:\"categories-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:9:\"sidebar-4\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("395","widget_ct-social","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("399","theme_mods_lovecraft","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575307886;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:4:{i:0;s:8:\"search-2\";i:1;s:10:\"archives-2\";i:2;s:12:\"categories-2\";i:3;s:6:\"meta-2\";}s:10:\"footer-one\";a:0:{}s:10:\"footer-two\";a:0:{}s:12:\"footer-three\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("400","widget_lovecraft_flickr_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("401","widget_widget_lovecraft_recent_comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("402","widget_widget_lovecraft_recent_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("410","theme_mods_minimal-blocks","a:14:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"header_textcolor\";s:6:\"000000\";s:13:\"theme_options\";a:3:{s:17:\"header_text_color\";s:7:\"#000000\";s:20:\"site_title_text_size\";i:20;s:21:\"enable_header_overlay\";b:0;}s:12:\"header_image\";s:13:\"remove-header\";s:16:\"background_image\";s:0:\"\";s:17:\"background_repeat\";s:9:\"no-repeat\";s:17:\"background_preset\";s:6:\"custom\";s:21:\"background_position_x\";s:6:\"center\";s:21:\"background_position_y\";s:3:\"top\";s:15:\"background_size\";s:4:\"auto\";s:21:\"background_attachment\";s:5:\"fixed\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1575308438;s:4:\"data\";a:6:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:4:{i:0;s:8:\"search-2\";i:1;s:10:\"archives-2\";i:2;s:12:\"categories-2\";i:3;s:6:\"meta-2\";}s:12:\"shop-sidebar\";a:0:{}s:14:\"footer-col-one\";a:0:{}s:14:\"footer-col-two\";a:0:{}s:16:\"footer-col-three\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("411","widget_minimal_blocks_tab_posts_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("412","widget_minimal_blocks_social_menu_widget","a:2:{s:12:\"_multiwidget\";i:1;i:3;a:1:{s:5:\"title\";s:6:\"分享\";}}","yes");
INSERT INTO `wp_options` VALUES("413","widget_minimal_blocks_author_info_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("415","_transient_minimal_blocks_categories","1","yes");
INSERT INTO `wp_options` VALUES("422","nav_menu_options","a:1:{s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("426","_transient_twentyfifteen_categories","1","yes");
INSERT INTO `wp_options` VALUES("431","theme_mods_minimal-portfolio","a:29:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:3;}s:18:\"custom_css_post_id\";i:39;s:12:\"header_image\";s:95:\"http://www.simonchen.cn/wp-content/uploads/2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg\";s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:36;s:3:\"url\";s:95:\"http://www.simonchen.cn/wp-content/uploads/2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg\";s:13:\"thumbnail_url\";s:95:\"http://www.simonchen.cn/wp-content/uploads/2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg\";s:6:\"height\";i:384;s:5:\"width\";i:1280;}s:38:\"minimal_portfolio_footer_facebook_link\";s:0:\"\";s:37:\"minimal_portfolio_footer_twitter_link\";s:0:\"\";s:37:\"minimal_portfolio_footer_youtube_link\";s:0:\"\";s:39:\"minimal_portfolio_footer_instagram_link\";s:0:\"\";s:37:\"minimal_portfolio_blog_sidebar_sticky\";b:0;s:45:\"minimal_portfolio_archive_blog_sidebar_sticky\";b:0;s:44:\"minimal_portfolio_single_blog_sidebar_sticky\";b:0;s:36:\"minimal_portfolio_post_slider_status\";b:0;s:35:\"minimal_portfolio_backto_top_status\";b:1;s:34:\"minimal_portfolio_copyright_author\";s:37:\"Copyright © 有态度的墨大先生\";s:38:\"minimal_portfolio_sticky_header_status\";b:1;s:35:\"minimal_portfolio_breadcrumb_status\";b:0;s:33:\"minimal_portfolio_blog_post_align\";s:4:\"left\";s:34:\"minimal_portfolio_blog_meta_author\";b:0;s:36:\"minimal_portfolio_blog_meta_category\";b:1;s:32:\"minimal_portfolio_blog_meta_date\";b:1;s:16:\"header_textcolor\";s:0:\"\";s:16:\"background_color\";s:6:\"ffffff\";s:11:\"custom_logo\";s:0:\"\";s:41:\"minimal_portfolio_portfolio_content_title\";s:24:\"有态度的墨大先生\";s:41:\"minimal_portfolio_single_blog_meta_author\";b:0;s:43:\"minimal_portfolio_single_blog_meta_category\";b:0;s:40:\"minimal_portfolio_single_blog_meta_share\";b:1;s:36:\"minimal_portfolio_blog_meta_comments\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("536","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("544","theme_mods_twentyseventeen","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("545","theme_mods_twentysixteen","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("546","_transient_twentysixteen_categories","1","yes");
INSERT INTO `wp_options` VALUES("784","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:17:\"2545229027@qq.com\";s:7:\"version\";s:5:\"5.2.5\";s:9:\"timestamp\";i:1576270257;}","no");
INSERT INTO `wp_options` VALUES("939","wph_settings","a:4:{s:15:\"module_settings\";a:23:{s:16:\"new_xml_rpc_path\";s:0:\"\";s:13:\"block_xml_rpc\";s:3:\"yes\";s:20:\"disable_xml_rpc_auth\";s:2:\"no\";s:18:\"remove_xml_rpc_tag\";s:2:\"no\";s:17:\"block_license_txt\";s:3:\"yes\";s:17:\"block_readme_html\";s:3:\"yes\";s:21:\"block_wp_activate_php\";s:3:\"yes\";s:17:\"block_wp_cron_php\";s:3:\"yes\";s:27:\"block_default_wp_signup_php\";s:3:\"yes\";s:29:\"block_default_wp_register_php\";s:3:\"yes\";s:20:\"block_other_wp_files\";s:3:\"yes\";s:6:\"author\";s:0:\"\";s:20:\"author_block_default\";s:3:\"yes\";s:20:\"new_wp_comments_post\";s:0:\"\";s:26:\"block_wp_comments_post_url\";s:3:\"yes\";s:6:\"search\";s:0:\"\";s:20:\"search_block_default\";s:3:\"yes\";s:20:\"disable_json_rest_v1\";s:2:\"no\";s:20:\"disable_json_rest_v2\";s:2:\"no\";s:15:\"block_json_rest\";s:2:\"no\";s:29:\"disable_json_rest_wphead_link\";s:2:\"no\";s:28:\"disable_json_rest_xmlrpc_rsd\";s:3:\"yes\";s:35:\"disable_json_rest_template_redirect\";s:2:\"no\";}s:13:\"recovery_code\";s:10:\"0dcb52cfef\";s:7:\"version\";s:7:\"1.5.9.9\";s:18:\"write_check_string\";s:16:\"1577174735_49203\";}","yes");
INSERT INTO `wp_options` VALUES("2968","admin_email_lifespan","1598079785","yes");
INSERT INTO `wp_options` VALUES("2969","db_upgraded","","yes");
INSERT INTO `wp_options` VALUES("2971","can_compress_scripts","0","no");
INSERT INTO `wp_options` VALUES("4323","_site_transient_timeout_php_check_f3408a2041a3252345cbba83e180fe85","1585293565","no");
INSERT INTO `wp_options` VALUES("4324","_site_transient_php_check_f3408a2041a3252345cbba83e180fe85","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("4325","_site_transient_timeout_browser_ac05ce2b54bf6619514b7c7c2e5ab81a","1585294209","no");
INSERT INTO `wp_options` VALUES("4326","_site_transient_browser_ac05ce2b54bf6619514b7c7c2e5ab81a","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"80.0.3987.122\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("4327","_site_transient_timeout_community-events-4282c607fbdfb7b306462d9420c17ebe","1584732614","no");
INSERT INTO `wp_options` VALUES("4328","_site_transient_community-events-4282c607fbdfb7b306462d9420c17ebe","a:3:{s:9:\"sandboxed\";b:0;s:8:\"location\";a:1:{s:2:\"ip\";s:12:\"101.227.12.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("4329","_transient_timeout_dash_v2_5438fb5baf31c513fff2b9a1067656a6","1584732614","no");
INSERT INTO `wp_options` VALUES("4330","_transient_dash_v2_5438fb5baf31c513fff2b9a1067656a6","<div class=\"rss-widget\"><p><strong>RSS错误：</strong> A feed could not be found at https://wordpress.org/news/feed/. A feed with an invalid mime type may fall victim to this error, or SimplePie was unable to auto-discover it.. Use force_feed() if you are certain this URL is a real feed.</p></div><div class=\"rss-widget\"><p><strong>RSS错误：</strong> A feed could not be found at https://planet.wordpress.org/feed/. A feed with an invalid mime type may fall victim to this error, or SimplePie was unable to auto-discover it.. Use force_feed() if you are certain this URL is a real feed.</p></div>","no");
INSERT INTO `wp_options` VALUES("4331","_transient_timeout_plugin_slugs","1584776149","no");
INSERT INTO `wp_options` VALUES("4332","_transient_plugin_slugs","a:4:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:33:\"classic-editor/classic-editor.php\";i:2;s:29:\"health-check/health-check.php\";i:3;s:37:\"wp-hide-security-enhancer/wp-hide.php\";}","no");
INSERT INTO `wp_options` VALUES("4334","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1584700243","no");
INSERT INTO `wp_options` VALUES("4335","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4672;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3969;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2666;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2544;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1958;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1800;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1778;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1481;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1468;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1466;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1446;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1417;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1399;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1299;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1182;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1172;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1120;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1101;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1089;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:981;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:871;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:869;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:864;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:848;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:785;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:763;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:763;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:752;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:742;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:742;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:714;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:702;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:702;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:696;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:679;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:659;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:645;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:642;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:634;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:633;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:625;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:621;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:583;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:576;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:574;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:569;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:569;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:558;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:550;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:543;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:542;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:532;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:532;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:531;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:528;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:517;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:510;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:498;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:496;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:495;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:487;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:486;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:482;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:473;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:467;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:462;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:456;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:440;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:429;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:428;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:425;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:423;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:422;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:420;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:420;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:419;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:409;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:405;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:395;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:394;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:392;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:384;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:382;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:380;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:379;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:374;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:370;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:369;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:367;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:357;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:354;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:351;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:338;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:338;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:335;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:334;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:332;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:330;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:330;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:324;}}","no");
INSERT INTO `wp_options` VALUES("4337","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/zh_CN/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"zh_CN\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/zh_CN/wordpress-5.3.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1584689729;s:15:\"version_checked\";s:5:\"5.3.2\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("4338","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1584689737;s:7:\"checked\";a:4:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.3\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.5\";s:29:\"health-check/health-check.php\";s:5:\"1.4.2\";s:37:\"wp-hide-security-enhancer/wp-hide.php\";s:7:\"1.5.9.9\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.3\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"health-check/health-check.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/health-check\";s:4:\"slug\";s:12:\"health-check\";s:6:\"plugin\";s:29:\"health-check/health-check.php\";s:11:\"new_version\";s:5:\"1.4.2\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/health-check/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/health-check.1.4.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:65:\"https://ps.w.org/health-check/assets/icon-256x256.png?rev=1823210\";s:2:\"1x\";s:57:\"https://ps.w.org/health-check/assets/icon.svg?rev=1828244\";s:3:\"svg\";s:57:\"https://ps.w.org/health-check/assets/icon.svg?rev=1828244\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/health-check/assets/banner-1544x500.png?rev=1823210\";s:2:\"1x\";s:67:\"https://ps.w.org/health-check/assets/banner-772x250.png?rev=1823210\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"wp-hide-security-enhancer/wp-hide.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:39:\"w.org/plugins/wp-hide-security-enhancer\";s:4:\"slug\";s:25:\"wp-hide-security-enhancer\";s:6:\"plugin\";s:37:\"wp-hide-security-enhancer/wp-hide.php\";s:11:\"new_version\";s:7:\"1.5.9.9\";s:3:\"url\";s:56:\"https://wordpress.org/plugins/wp-hide-security-enhancer/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/wp-hide-security-enhancer.1.5.9.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/wp-hide-security-enhancer/assets/icon-256x256.png?rev=1974395\";s:2:\"1x\";s:78:\"https://ps.w.org/wp-hide-security-enhancer/assets/icon-128x128.png?rev=1974395\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/wp-hide-security-enhancer/assets/banner-1544x500.png?rev=1573670\";s:2:\"1x\";s:80:\"https://ps.w.org/wp-hide-security-enhancer/assets/banner-772x250.png?rev=1376480\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("4339","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1584689737;s:7:\"checked\";a:2:{s:17:\"minimal-portfolio\";s:5:\"1.0.8\";s:14:\"twentynineteen\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("4340","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("4341","aio_wp_security_configs","a:93:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:17:\"2545229027@qq.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"pff72vd5znf4maidi762\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"hd041v7av0wnbjdosecw\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:17:\"2545229027@qq.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:27:\"aiowps_max_file_upload_size\";i:30;s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:1:\"1\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:17:\"2545229027@qq.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";}","yes");
INSERT INTO `wp_options` VALUES("4346","_site_transient_timeout_theme_roots","1584692372","no");
INSERT INTO `wp_options` VALUES("4347","_site_transient_theme_roots","a:2:{s:17:\"minimal-portfolio\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("4348","_transient_timeout_users_online","1584692977","no");
INSERT INTO `wp_options` VALUES("4349","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1584719977;s:10:\"ip_address\";s:14:\"101.227.12.253\";}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("8","8","_wp_attached_file","2019/11/head-Re300.png");
INSERT INTO `wp_postmeta` VALUES("9","8","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"file\";s:22:\"2019/11/head-Re300.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"head-Re300-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("26","18","_wp_attached_file","2019/11/cropped-simonGlass－show.png");
INSERT INTO `wp_postmeta` VALUES("27","18","_wp_attachment_context","custom-header");
INSERT INTO `wp_postmeta` VALUES("28","18","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:750;s:4:\"file\";s:37:\"2019/11/cropped-simonGlass－show.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"cropped-simonGlass－show-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"cropped-simonGlass－show-300x225.png\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"cropped-simonGlass－show-768x576.png\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:17:\"attachment_parent\";i:13;}");
INSERT INTO `wp_postmeta` VALUES("29","18","_wp_attachment_custom_header_last_used_online-cv-resume","1575307089");
INSERT INTO `wp_postmeta` VALUES("30","18","_wp_attachment_is_custom_header","online-cv-resume");
INSERT INTO `wp_postmeta` VALUES("59","28","_wp_attached_file","2019/11/cropped-0cc92b2421bc2b0058cb2d57d79afb5d.png");
INSERT INTO `wp_postmeta` VALUES("60","28","_wp_attachment_context","custom-header");
INSERT INTO `wp_postmeta` VALUES("61","28","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:582;s:4:\"file\";s:52:\"2019/11/cropped-0cc92b2421bc2b0058cb2d57d79afb5d.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"cropped-0cc92b2421bc2b0058cb2d57d79afb5d-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:52:\"cropped-0cc92b2421bc2b0058cb2d57d79afb5d-300x146.png\";s:5:\"width\";i:300;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:52:\"cropped-0cc92b2421bc2b0058cb2d57d79afb5d-768x372.png\";s:5:\"width\";i:768;s:6:\"height\";i:372;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:53:\"cropped-0cc92b2421bc2b0058cb2d57d79afb5d-1024x497.png\";s:5:\"width\";i:1024;s:6:\"height\";i:497;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:17:\"attachment_parent\";i:9;}");
INSERT INTO `wp_postmeta` VALUES("65","30","_wp_attached_file","2019/11/cropped-JXOCYQZO1192W.jpg");
INSERT INTO `wp_postmeta` VALUES("66","30","_wp_attachment_context","custom-header");
INSERT INTO `wp_postmeta` VALUES("67","30","_wp_attachment_metadata","a:6:{s:5:\"width\";i:860;s:6:\"height\";i:314;s:4:\"file\";s:33:\"2019/11/cropped-JXOCYQZO1192W.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"cropped-JXOCYQZO1192W-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"cropped-JXOCYQZO1192W-300x110.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"cropped-JXOCYQZO1192W-768x280.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:280;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:17:\"attachment_parent\";i:6;}");
INSERT INTO `wp_postmeta` VALUES("85","35","_wp_attached_file","2019/12/89ce42fe1acb3a15f3559fa9271345d8.jpg");
INSERT INTO `wp_postmeta` VALUES("86","35","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:44:\"2019/12/89ce42fe1acb3a15f3559fa9271345d8.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"89ce42fe1acb3a15f3559fa9271345d8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"89ce42fe1acb3a15f3559fa9271345d8-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"89ce42fe1acb3a15f3559fa9271345d8-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"89ce42fe1acb3a15f3559fa9271345d8-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"27\";s:3:\"iso\";s:3:\"250\";s:13:\"shutter_speed\";s:6:\"0.0125\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("89","36","_wp_attached_file","2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg");
INSERT INTO `wp_postmeta` VALUES("90","36","_wp_attachment_context","custom-header");
INSERT INTO `wp_postmeta` VALUES("91","36","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:384;s:4:\"file\";s:52:\"2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"cropped-89ce42fe1acb3a15f3559fa9271345d8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:51:\"cropped-89ce42fe1acb3a15f3559fa9271345d8-300x90.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:90;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:52:\"cropped-89ce42fe1acb3a15f3559fa9271345d8-768x230.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:53:\"cropped-89ce42fe1acb3a15f3559fa9271345d8-1024x307.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:307;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:17:\"attachment_parent\";i:35;}");
INSERT INTO `wp_postmeta` VALUES("92","36","_wp_attachment_custom_header_last_used_minimal-portfolio","1575460542");
INSERT INTO `wp_postmeta` VALUES("93","36","_wp_attachment_is_custom_header","minimal-portfolio");
INSERT INTO `wp_postmeta` VALUES("149","65","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("150","65","_edit_lock","1583828701:1");
INSERT INTO `wp_postmeta` VALUES("170","65","_wp_old_date","2019-12-05");
INSERT INTO `wp_postmeta` VALUES("171","75","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("172","75","_edit_lock","1583828546:1");
INSERT INTO `wp_postmeta` VALUES("175","75","_wp_old_date","2019-12-05");
INSERT INTO `wp_postmeta` VALUES("176","77","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("177","77","_edit_lock","1583829300:1");
INSERT INTO `wp_postmeta` VALUES("180","77","_wp_old_date","2019-12-05");
INSERT INTO `wp_postmeta` VALUES("182","75","_wp_old_date","2015-07-05");
INSERT INTO `wp_postmeta` VALUES("184","75","_wp_old_date","2015-06-05");
INSERT INTO `wp_postmeta` VALUES("214","92","_wp_attached_file","2019/12/qrcode_for_gh_99d774cc7790_430.jpg");
INSERT INTO `wp_postmeta` VALUES("215","92","_wp_attachment_metadata","a:5:{s:5:\"width\";i:370;s:6:\"height\";i:370;s:4:\"file\";s:42:\"2019/12/qrcode_for_gh_99d774cc7790_430.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:42:\"qrcode_for_gh_99d774cc7790_430-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:42:\"qrcode_for_gh_99d774cc7790_430-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("234","3","_edit_lock","1577433545:1");
INSERT INTO `wp_postmeta` VALUES("235","77","_oembed_7e6fd2af74bae91e00cee3ed3ab5281a","{{unknown}}");
INSERT INTO `wp_postmeta` VALUES("238","77","_oembed_7127a93d1c7c941c78353f1c3b6ef762","{{unknown}}");
INSERT INTO `wp_postmeta` VALUES("251","122","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("252","122","_wp_trash_meta_time","1583829276");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES("3","1","2019-11-06 16:36:36","2019-11-06 08:36:36","<!-- wp:heading --><h2>我们是谁</h2><!-- /wp:heading --><!-- wp:paragraph --><p>我们的站点地址是：http://www.simonchen.cn。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>我们收集何种及为何收集个人数据</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>评论</h3><!-- /wp:heading --><!-- wp:paragraph --><p>当访客留下评论时，我们会收集评论表单所显示的数据，和访客的IP地址及浏览器的user agent字符串来帮助检查垃圾评论。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>由您的电子邮件地址所生成的匿名化字符串（又称为哈希）可能会被提供给Gravatar服务确认您是否有使用该服务。Gravatar服务的隐私政策在此：https://automattic.com/privacy/。在您的评论获批准后，您的资料图片将在您的评论旁公开展示。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>媒体</h3><!-- /wp:heading --><!-- wp:paragraph --><p>如果您向此网站上传图片，您应当避免上传那些有嵌入地理位置信息（EXIF GPS）的图片。此网站的访客将可以下载并提取此网站的图片中的位置信息。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>联系表单</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>如果您在我们的站点上留下评论，您可以选择用cookies保存您的姓名、电子邮件地址和网站。这是通过让您可以不用在评论时再次填写相关内容而向您提供方便。这些cookies会保留一年。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>如果您访问我们的登录页，我们会设置一个临时的cookie来确认您的浏览器是否接受cookies。此cookie不包含个人数据，且会在您关闭浏览器时被丢弃。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>当您登录时，我们也会设置多个cookies来保存您的登录信息及屏幕显示选项。登录cookies会保留两天，而屏幕显示选项cookies会保留一年。如果您选择了“记住我”，您的登录会保留两周。如果您注销，登录cookies将被移除。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>如果您编辑或发布文章，我们会在您的浏览器中保存一个额外的cookie。这个cookie不包含个人数据而只记录了您刚才编辑的文章的ID。这个小甜饼会保留一天。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>其他站点的嵌入内容</h3><!-- /wp:heading --><!-- wp:paragraph --><p>此站点上的文章可能会包含嵌入的内容（如视频、图像、文章等）。来自其他站点的嵌入内容的行为和您直接访问这些其他站点没有区别。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>这些站点可能会收集关于您的数据、使用cookies、嵌入额外的第三方跟踪程序及监视您与这些嵌入内容的交互，包括在您有这些站点的账户并登录了这些站点时，跟踪您与嵌入内容的交互。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>统计</h3><!-- /wp:heading --><!-- wp:heading --><h2>我们与谁共享您的信息</h2><!-- /wp:heading --><!-- wp:heading --><h2>我们保留多久您的信息</h2><!-- /wp:heading --><!-- wp:paragraph --><p>如果您留下评论，评论和其元数据将被无限期保存。我们这样做以便能识别并自动批准任何后续评论，而不用将这些后续评论加入待审队列。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>对于本网站的注册用户，我们也会保存用户在个人资料中提供的个人信息。所有用户可以在任何时候查看、编辑或删除他们的个人信息（除了不能变更用户名外）、站点管理员也可以查看及编辑那些信息。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>您对您的信息有什么权利</h2><!-- /wp:heading --><!-- wp:paragraph --><p>如果您有此站点的账户，或曾经留下评论，您可以请求我们提供我们所拥有的您的个人数据的导出文件，这也包括了所有您提供给我们的数据。您也可以要求我们抹除所有关于您的个人数据。这不包括我们因管理、法规或安全需要而必须保留的数据。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>我们将您的信息发送到哪</h2><!-- /wp:heading --><!-- wp:paragraph --><p>访客评论可能会被自动垃圾评论监测服务检查。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>您的联系信息</h2><!-- /wp:heading --><!-- wp:heading --><h2>其他信息</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>我们如何保护您的数据</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>我们有何种数据泄露处理流程</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>我们从哪些第三方接收数据</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>我们通过用户数据进行何种自动决策及/或归纳</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>行业监管披露要求</h3><!-- /wp:heading -->","隐私政策","","draft","closed","open","","privacy-policy","","","2019-11-06 16:36:36","2019-11-06 08:36:36","","0","http://www.simonchen.cn/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("8","1","2019-11-07 10:16:25","2019-11-07 02:16:25","","head-Re300","","inherit","open","closed","","head-re300","","","2019-11-07 10:16:25","2019-11-07 02:16:25","","0","http://www.simonchen.cn/wp-content/uploads/2019/11/head-Re300.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("18","1","2019-12-03 01:17:45","2019-12-02 17:17:45","","cropped-simonGlass－show.png","","inherit","open","closed","","cropped-simonglass%ef%bc%8dshow-png","","","2019-12-03 01:17:45","2019-12-02 17:17:45","","0","http://www.simonchen.cn/wp-content/uploads/2019/11/cropped-simonGlass－show.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("28","1","2019-12-03 01:54:11","2019-12-02 17:54:11","","cropped-0cc92b2421bc2b0058cb2d57d79afb5d.png","","inherit","open","closed","","cropped-0cc92b2421bc2b0058cb2d57d79afb5d-png","","","2019-12-03 01:54:11","2019-12-02 17:54:11","","0","http://www.simonchen.cn/wp-content/uploads/2019/11/cropped-0cc92b2421bc2b0058cb2d57d79afb5d.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("30","1","2019-12-03 01:54:41","2019-12-02 17:54:41","","cropped-JXOCYQZO1192W.jpg","","inherit","open","closed","","cropped-jxocyqzo1192w-jpg","","","2019-12-03 01:54:41","2019-12-02 17:54:41","","0","http://www.simonchen.cn/wp-content/uploads/2019/11/cropped-JXOCYQZO1192W.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("35","1","2019-12-04 19:49:41","2019-12-04 11:49:41","","89ce42fe1acb3a15f3559fa9271345d8","","inherit","closed","closed","","89ce42fe1acb3a15f3559fa9271345d8","","","2019-12-04 19:49:41","2019-12-04 11:49:41","","0","http://www.simonchen.cn/wp-content/uploads/2019/12/89ce42fe1acb3a15f3559fa9271345d8.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("36","1","2019-12-04 19:50:11","2019-12-04 11:50:11","","cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg","","inherit","closed","closed","","cropped-89ce42fe1acb3a15f3559fa9271345d8-jpg","","","2019-12-04 19:50:11","2019-12-04 11:50:11","","0","http://www.simonchen.cn/wp-content/uploads/2019/12/cropped-89ce42fe1acb3a15f3559fa9271345d8.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("39","1","2019-12-04 19:55:42","2019-12-04 11:55:42",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
.page-header .page-title {
	  text-align: left;
    color: #333;
    font-size: 30px;
    font-weight: bold;
    -ms-word-wrap: break-word;
    word-wrap: break-word;
}
","minimal-portfolio","","publish","closed","closed","","minimal-portfolio","","","2020-03-10 16:34:36","2020-03-10 08:34:36","","0","http://www.simonchen.cn/2019/12/04/minimal-portfolio/","0","custom_css","","0");
INSERT INTO `wp_posts` VALUES("40","1","2019-12-04 19:55:42","2019-12-04 11:55:42",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 19:55:42","2019-12-04 11:55:42","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("44","1","2019-12-04 23:24:17","2019-12-04 15:24:17",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    /* font-weight: 500; */
    margin: 0;
    color: #222;
    font-weight: bold;
}","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 23:24:17","2019-12-04 15:24:17","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("46","1","2019-12-04 23:26:10","2019-12-04 15:26:10",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 23:26:10","2019-12-04 15:26:10","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("48","1","2019-12-04 23:31:36","2019-12-04 15:31:36",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 23:31:36","2019-12-04 15:31:36","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("50","1","2019-12-04 23:34:50","2019-12-04 15:34:50",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier *, *:before, *:after {
    box-sizing: inherit;
    color: #fff;
}","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 23:34:50","2019-12-04 15:34:50","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("52","1","2019-12-04 23:38:09","2019-12-04 15:38:09",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-04 23:38:09","2019-12-04 15:38:09","","39","http://www.simonchen.cn/2019/12/04/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("61","1","2019-12-05 00:56:48","2019-12-04 16:56:48",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
.ICP_Num p {
    margin-bottom: 1.5em;
    display:contents;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-05 00:56:48","2019-12-04 16:56:48","","39","http://www.simonchen.cn/2019/12/05/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("63","1","2019-12-05 00:57:23","2019-12-04 16:57:23",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-05 00:57:23","2019-12-04 16:57:23","","39","http://www.simonchen.cn/2019/12/05/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("65","1","2015-02-10 17:13:09","2015-02-10 09:13:09","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？

<img class=\"size-full alignleft\" src=\"https://img.zcool.cn/community/01ded4554231800000019ae9b499db.jpg@720w_1l_2o_100sh.jpg\" width=\"720\" height=\"540\" />","投币电话","","publish","closed","closed","","65","","","2020-03-10 16:24:15","2020-03-10 08:24:15","","0","http://www.simonchen.cn/?p=65","0","post","","0");
INSERT INTO `wp_posts` VALUES("66","1","2019-12-05 01:13:09","2019-12-04 17:13:09","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？
<h6><span style=\"color: #999999;\">鼠绘，Photoshop CC</span></h6>
<img class=\"alignnone size-full wp-image-15\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/phone.jpg\" alt=\"\" width=\"1024\" height=\"768\" />","","","inherit","closed","closed","","65-revision-v1","","","2019-12-05 01:13:09","2019-12-04 17:13:09","","65","http://www.simonchen.cn/2019/12/05/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("67","1","2019-12-05 01:13:50","2019-12-04 17:13:50","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？
<h6><span style=\"color: #999999;\">鼠绘，Photoshop CC</span></h6>
<img class=\"alignnone size-full wp-image-15\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/phone.jpg\" alt=\"\" width=\"1024\" height=\"768\" />","投币电话","","inherit","closed","closed","","65-revision-v1","","","2019-12-05 01:13:50","2019-12-04 17:13:50","","65","http://www.simonchen.cn/2019/12/05/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("68","1","2019-12-05 01:14:25","2019-12-04 17:14:25","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？

<img class=\"alignnone size-full wp-image-15\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/phone.jpg\" alt=\"\" width=\"1024\" height=\"768\" />","投币电话","","inherit","closed","closed","","65-revision-v1","","","2019-12-05 01:14:25","2019-12-04 17:14:25","","65","http://www.simonchen.cn/2019/12/05/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("75","1","2015-05-05 19:24:54","2015-05-05 11:24:54","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"size-full alignleft\" src=\"https://img.zcool.cn/community/015821559e38306ac7257aeaf2c7da.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />","怀念 · GBA","","publish","closed","closed","","%e6%80%80%e5%bf%b5-%c2%b7-gba","","","2020-03-10 16:24:45","2020-03-10 08:24:45","","0","http://www.simonchen.cn/?p=75","0","post","","0");
INSERT INTO `wp_posts` VALUES("76","1","2019-12-05 02:24:54","2019-12-04 18:24:54","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"alignnone size-full wp-image-12\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/怀念-·-GameBoy-AdvanceUI其他UI-墨大先生-原创作品-站酷-ZCOOL.png\" alt=\"\" width=\"1280\" height=\"960\" />","怀念 · GBA","","inherit","closed","closed","","75-revision-v1","","","2019-12-05 02:24:54","2019-12-04 18:24:54","","75","http://www.simonchen.cn/2019/12/05/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("77","1","2015-06-19 19:31:45","2015-06-19 11:31:45","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。
不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />
</br>
<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;

&nbsp;","我的眼镜","","publish","closed","closed","","%e6%88%91%e7%9a%84%e7%9c%bc%e9%95%9c","","","2020-03-10 16:36:23","2020-03-10 08:36:23","","0","http://www.simonchen.cn/?p=77","0","post","","0");
INSERT INTO `wp_posts` VALUES("78","1","2019-12-05 02:31:45","2019-12-04 18:31:45","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"alignnone size-full wp-image-14\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/Grid.png\" alt=\"\" width=\"992\" height=\"630\" />

<img class=\"alignnone size-full wp-image-13\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/simonGlass－show.png\" alt=\"\" width=\"1024\" height=\"768\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-05 02:31:45","2019-12-04 18:31:45","","77","http://www.simonchen.cn/2019/12/05/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("80","1","2019-12-05 02:35:06","2019-12-04 18:35:06",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-05 02:35:06","2019-12-04 18:35:06","","39","http://www.simonchen.cn/2019/12/05/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("82","1","2019-12-05 02:36:36","2019-12-04 18:36:36",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
.page-header .page-title {
    text-align: center;
    color: #0666b9;
    font-size: 30px;
    font-weight: bold;
    -ms-word-wrap: break-word;
    word-wrap: break-word;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-05 02:36:36","2019-12-04 18:36:36","","39","http://www.simonchen.cn/2019/12/05/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("83","1","2019-12-05 02:42:30","2019-12-04 18:42:30","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"alignnone  wp-image-13\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/simonGlass－show.png\" alt=\"\" width=\"992\" height=\"741\" />

<img class=\"alignnone  wp-image-14\" src=\"http://www.simonchen.cn/wp-content/uploads/2019/11/Grid.png\" alt=\"\" width=\"992\" height=\"630\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-05 02:42:30","2019-12-04 18:42:30","","77","http://www.simonchen.cn/2019/12/05/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("87","1","2019-12-05 22:10:40","2019-12-05 14:10:40",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
.page-header .page-title {
			text-align: left;
    color: #333;
    font-size: 30px;
    font-weight: bold;
    -ms-word-wrap: break-word;
    word-wrap: break-word;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-05 22:10:40","2019-12-05 14:10:40","","39","http://www.simonchen.cn/2019/12/05/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("92","1","2019-12-05 23:45:40","2019-12-05 15:45:40","","qrcode_for_gh_99d774cc7790_430","","inherit","closed","closed","","qrcode_for_gh_99d774cc7790_430","","","2019-12-05 23:45:40","2019-12-05 15:45:40","","0","http://www.simonchen.cn/wp-content/uploads/2019/12/qrcode_for_gh_99d774cc7790_430.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("96","1","2019-12-06 11:02:36","2019-12-06 03:02:36",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
.page-header .page-title {
	  text-align: center;
    color: #333;
    font-size: 30px;
    font-weight: bold;
    -ms-word-wrap: break-word;
    word-wrap: break-word;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2019-12-06 11:02:36","2019-12-06 03:02:36","","39","http://www.simonchen.cn/2019/12/06/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("102","1","2020-03-10 16:36:32","2020-03-10 08:36:32","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。
不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />

<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;

&nbsp;","我的眼镜","","inherit","closed","closed","","77-autosave-v1","","","2020-03-10 16:36:32","2020-03-10 08:36:32","","77","http://www.simonchen.cn/2019/12/27/77-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("103","1","2019-12-27 14:58:30","2019-12-27 06:58:30","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/01c32a6a4u80ff61e73b8576c86fafc3?fid=2583895617-250528-951012542181272&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-rFXKO3s7tAV2ExBaElUtSwh1SNs%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8363862595340600164&amp;dp-callid=0&amp;time=1577426400&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"1024\" height=\"768\" />

<img class=\"size-full aligncenter\" src=\"https://thumbnail0.baidupcs.com/thumbnail/28e9c5939kd0a08e50f9ae28a116324f?fid=2583895617-250528-761846330555425&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-%2bryxDql%2bbbIOUkowpf8%2b8Xo9Yf4%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8363862595340600164&amp;dp-callid=0&amp;time=1577426400&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"992\" height=\"630\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-27 14:58:30","2019-12-27 06:58:30","","77","http://www.simonchen.cn/2019/12/27/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("104","1","2020-03-10 16:16:49","2020-03-10 08:16:49","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"aligncenter size-full\" src=\"https://img.zcool.cn/community/015821559e38306ac7257aeaf2c7da.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />","怀念 · GBA","","inherit","closed","closed","","75-autosave-v1","","","2020-03-10 16:16:49","2020-03-10 08:16:49","","75","http://www.simonchen.cn/2019/12/27/75-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("105","1","2019-12-27 15:00:53","2019-12-27 07:00:53","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/0b8e3b0cbt5559a4ddfbc104374908ba?fid=2583895617-250528-508464538203309&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-uF6NVV47Vw0SvF7hUjjcX%2bnMbus%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8363918395301115430&amp;dp-callid=0&amp;time=1577430000&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"1280\" height=\"960\" />","怀念 · GBA","","inherit","closed","closed","","75-revision-v1","","","2019-12-27 15:00:53","2019-12-27 07:00:53","","75","http://www.simonchen.cn/2019/12/27/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("106","1","2019-12-27 15:02:21","2019-12-27 07:02:21","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/0479d70d4r5ce6f90b68e497527affb4?fid=2583895617-250528-715095755051865&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-d%2fSXK0prfCAqNL8vpFonWXFgzO4%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8363941827810838264&amp;dp-callid=0&amp;time=1577430000&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"1024\" height=\"768\" />","投币电话","","inherit","closed","closed","","65-revision-v1","","","2019-12-27 15:02:21","2019-12-27 07:02:21","","65","http://www.simonchen.cn/2019/12/27/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("108","1","2019-12-30 09:19:40","2019-12-30 01:19:40","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/01c32a6a4u80ff61e73b8576c86fafc3?fid=2583895617-250528-951012542181272&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-owo9AVl7mNGDDELSp%2b8jx8qrars%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8427985350385185602&amp;dp-callid=0&amp;time=1577667600&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"1024\" height=\"768\" />

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/28e9c5939kd0a08e50f9ae28a116324f?fid=2583895617-250528-761846330555425&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-zRSwwHmtDQLvn4dNsYezhCXOwEI%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8427985350385185602&amp;dp-callid=0&amp;time=1577667600&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"992\" height=\"630\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-30 09:19:40","2019-12-30 01:19:40","","77","http://www.simonchen.cn/2019/12/30/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("109","1","2019-12-30 09:25:54","2019-12-30 01:25:54","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"aligncenter size-full\" src=\"https://qdcu01.baidupcs.com/file/01c32a6a4u80ff61e73b8576c86fafc3?bkt=en-864c1d195a8f2f4134ce879707d7b9a407efd164c777ab4be8735b4f7e83025b0b773556170000bc88551e5a4c239a4ce4d7b18d0128bbfd976e9c78090f4e2a&amp;fid=2583895617-250528-951012542181272&amp;time=1577669076&amp;sign=FDTAXGERLQBHSKfW-DCb740ccc5511e5e8fedcff06b081203-kpo4quygTnDR0L2GhbPDcciuhUQ%3D&amp;to=65&amp;size=150133&amp;sta_dx=150133&amp;sta_cs=0&amp;sta_ft=png&amp;sta_ct=1&amp;sta_mt=1&amp;fm2=MH%2CQingdao%2CAnywhere%2C%2Cheilongjiang%2Ccnc&amp;ctime=1577429814&amp;mtime=1577429814&amp;resv0=cdnback&amp;resv1=0&amp;resv2=rlim&amp;resv3=5&amp;resv4=150133&amp;vuk=2583895617&amp;iv=0&amp;htype=&amp;randtype=&amp;newver=1&amp;newfm=1&amp;secfm=1&amp;flow_ver=3&amp;pkey=en-eb9634b2a75499ff84afd28ec7295c851bce8e08ab78ee83fbe9991bdd2af8b9f2a13dc8c439572c8bb959a8e51483919a5ee9f07ef028a9305a5e1275657320&amp;sl=68616270&amp;expires=8h&amp;rt=sh&amp;r=952116364&amp;vbdid=1111761185&amp;fin=simonGlass%EF%BC%8Dshow.png&amp;fn=simonGlass%EF%BC%8Dshow.png&amp;rtype=1&amp;dp-logid=8428088066058310849&amp;dp-callid=0.1&amp;hps=1&amp;tsl=200&amp;csl=200&amp;csign=LT9G9oq378DFNtp1Tx4F91cabJM%3D&amp;so=0&amp;ut=6&amp;uter=4&amp;serv=0&amp;uc=3518852009&amp;ti=0887d9faa0e992647082c3b7744f8b5d10dbc74f0e5e6af1305a5e1275657320&amp;reqlabel=250528_f_cd5c62ed60f84328b223abeb453da23e_-1_b5188b0592fe25712813c8a0a7bfb2e5&amp;by=themis\" width=\"1024\" height=\"768\" />

<img class=\"aligncenter size-full\" src=\"https://thumbnail0.baidupcs.com/thumbnail/28e9c5939kd0a08e50f9ae28a116324f?fid=2583895617-250528-761846330555425&amp;rt=pr&amp;sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-zRSwwHmtDQLvn4dNsYezhCXOwEI%3d&amp;expires=8h&amp;chkbd=0&amp;chkv=0&amp;dp-logid=8427985350385185602&amp;dp-callid=0&amp;time=1577667600&amp;size=c10000_u10000&amp;quality=90&amp;vuk=2583895617&amp;ft=image\" width=\"992\" height=\"630\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-30 09:25:54","2019-12-30 01:25:54","","77","http://www.simonchen.cn/2019/12/30/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("110","1","2019-12-30 22:04:32","2019-12-30 14:04:32","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。

<img class=\"aligncenter size-full\" src=\"http://q3bw5nao6.bkt.clouddn.com/simonGlass%EF%BC%8Dshow.png\" width=\"1024\" height=\"768\" />

<img class=\"aligncenter size-full\" src=\"http://q3bw5nao6.bkt.clouddn.com/simonGlass%EF%BC%8DGrid.png\" width=\"992\" height=\"630\" />","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2019-12-30 22:04:32","2019-12-30 14:04:32","","77","http://www.simonchen.cn/2019/12/30/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("111","1","2019-12-30 22:05:19","2019-12-30 14:05:19","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"aligncenter size-full\" src=\"http://q3bw5nao6.bkt.clouddn.com/GameBoy-show.png\" width=\"1280\" height=\"960\" />","怀念 · GBA","","inherit","closed","closed","","75-revision-v1","","","2019-12-30 22:05:19","2019-12-30 14:05:19","","75","http://www.simonchen.cn/2019/12/30/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("112","1","2019-12-30 22:05:56","2019-12-30 14:05:56","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？

<img class=\"aligncenter size-full\" src=\"http://q3bw5nao6.bkt.clouddn.com/phone-show.jpg\" width=\"1024\" height=\"768\" />","投币电话","","inherit","closed","closed","","65-revision-v1","","","2019-12-30 22:05:56","2019-12-30 14:05:56","","65","http://www.simonchen.cn/2019/12/30/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("117","1","2020-03-10 16:23:10","2020-03-10 08:23:10","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"aligncenter size-full\" src=\"https://img.zcool.cn/community/015821559e38306ac7257aeaf2c7da.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />","怀念 · GBA","","inherit","closed","closed","","75-revision-v1","","","2020-03-10 16:23:10","2020-03-10 08:23:10","","75","http://www.simonchen.cn/2020/03/10/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("118","1","2020-03-10 16:24:15","2020-03-10 08:24:15","在不远的将来，
通讯设备将变得更加先进，
还会不会有人记得投币电话曾经存在？

<img class=\"size-full alignleft\" src=\"https://img.zcool.cn/community/01ded4554231800000019ae9b499db.jpg@720w_1l_2o_100sh.jpg\" width=\"720\" height=\"540\" />","投币电话","","inherit","closed","closed","","65-revision-v1","","","2020-03-10 16:24:15","2020-03-10 08:24:15","","65","http://www.simonchen.cn/2020/03/10/65-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("119","1","2020-03-10 16:24:45","2020-03-10 08:24:45","记得上初中那会儿上课偷偷地玩，结果被老师没收n次……
现在出的游戏设备都很先进了，可是怎么都玩不出那种痛快的感觉了，好怀念。

<img class=\"size-full alignleft\" src=\"https://img.zcool.cn/community/015821559e38306ac7257aeaf2c7da.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />","怀念 · GBA","","inherit","closed","closed","","75-revision-v1","","","2020-03-10 16:24:45","2020-03-10 08:24:45","","75","http://www.simonchen.cn/2020/03/10/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("120","1","2020-03-10 16:26:58","2020-03-10 08:26:58","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。

不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />

<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2020-03-10 16:26:58","2020-03-10 08:26:58","","77","http://www.simonchen.cn/2020/03/10/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("121","1","2020-03-10 16:32:55","2020-03-10 08:32:55","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。
不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />
<br/>
<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;

&nbsp;","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2020-03-10 16:32:55","2020-03-10 08:32:55","","77","http://www.simonchen.cn/2020/03/10/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("122","1","2020-03-10 16:34:36","2020-03-10 08:34:36","{
    \"custom_css[minimal-portfolio]\": {
        \"value\": \".header-banner {\\n    overflow: hidden;\\n    background-color: #e9eef4;\\n}\\n\\n.site-title {\\n    font-size: 20px;\\n    margin: 0;\\n    color: #222;\\n    font-weight: bold;\\n}\\n.site-branding .site-description {\\n    line-height: 30px;\\n    margin-bottom: 0;\\n    color: #999;\\n}\\n*, *:before, *:after {\\n    box-sizing: inherit;\\n    color: #999;\\n}\\n.copyright a {\\n    color: #999;\\n}\\n.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {\\n    box-sizing: inherit;\\n    color: #fff;\\n}\\np.ICP_Num {\\n    margin-bottom: 1.5em;\\n    display:contents;\\n}\\n.page-header {\\n    background: #e9eef4;\\n    border-radius: 0;\\n    position: relative;\\n}\\n.page-header .page-title {\\n\\t  text-align: left;\\n    color: #333;\\n    font-size: 30px;\\n    font-weight: bold;\\n    -ms-word-wrap: break-word;\\n    word-wrap: break-word;\\n}\\n\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-03-10 08:34:36\"
    }
}","","","trash","closed","closed","","8174f8f5-edcb-478a-9c04-9cc39c2447f7","","","2020-03-10 16:34:36","2020-03-10 08:34:36","","0","http://www.simonchen.cn/2020/03/10/8174f8f5-edcb-478a-9c04-9cc39c2447f7/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("123","1","2020-03-10 16:34:36","2020-03-10 08:34:36",".header-banner {
    overflow: hidden;
    background-color: #e9eef4;
}

.site-title {
    font-size: 20px;
    margin: 0;
    color: #222;
    font-weight: bold;
}
.site-branding .site-description {
    line-height: 30px;
    margin-bottom: 0;
    color: #999;
}
*, *:before, *:after {
    box-sizing: inherit;
    color: #999;
}
.copyright a {
    color: #999;
}
.icon-magnifier,.icon-magnifier:before, .icon-magnifier:after {
    box-sizing: inherit;
    color: #fff;
}
p.ICP_Num {
    margin-bottom: 1.5em;
    display:contents;
}
.page-header {
    background: #e9eef4;
    border-radius: 0;
    position: relative;
}
.page-header .page-title {
	  text-align: left;
    color: #333;
    font-size: 30px;
    font-weight: bold;
    -ms-word-wrap: break-word;
    word-wrap: break-word;
}
","minimal-portfolio","","inherit","closed","closed","","39-revision-v1","","","2020-03-10 16:34:36","2020-03-10 08:34:36","","39","http://www.simonchen.cn/2020/03/10/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("124","1","2020-03-10 16:36:07","2020-03-10 08:36:07","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。
不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />

<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;

&nbsp;","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2020-03-10 16:36:07","2020-03-10 08:36:07","","77","http://www.simonchen.cn/2020/03/10/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("125","1","2020-03-10 16:36:23","2020-03-10 08:36:23","毕业那年配的眼镜，不知不觉已经陪伴我三年多了。
不是什么名牌，但是戴起来很舒服。<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/0156aa55a8641e6ac72581782f5e8a.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"540\" />
</br>
<img class=\"alignleft size-full\" src=\"https://img.zcool.cn/community/01830a55ba47fa32f87528a1196fce.png@720w_1l_2o_100sh.png\" width=\"720\" height=\"457\" />

&nbsp;

&nbsp;

&nbsp;","我的眼镜","","inherit","closed","closed","","77-revision-v1","","","2020-03-10 16:36:23","2020-03-10 08:36:23","","77","http://www.simonchen.cn/2020/03/10/77-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("126","1","2020-03-20 15:30:09","0000-00-00 00:00:00","","自动草稿","","auto-draft","closed","closed","","","","","2020-03-20 15:30:09","0000-00-00 00:00:00","","0","http://www.simonchen.cn/?p=126","0","post","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES("65","4","0");
INSERT INTO `wp_term_relationships` VALUES("65","6","0");
INSERT INTO `wp_term_relationships` VALUES("65","7","0");
INSERT INTO `wp_term_relationships` VALUES("75","4","0");
INSERT INTO `wp_term_relationships` VALUES("75","6","0");
INSERT INTO `wp_term_relationships` VALUES("75","7","0");
INSERT INTO `wp_term_relationships` VALUES("77","4","0");
INSERT INTO `wp_term_relationships` VALUES("77","6","0");
INSERT INTO `wp_term_relationships` VALUES("77","7","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","nav_menu","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","post_tag","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","post_tag","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","category","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","category","","0","0");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES("1","未分类","uncategorized","0");
INSERT INTO `wp_terms` VALUES("3","关于我","%e5%85%b3%e4%ba%8e%e6%88%91","0");
INSERT INTO `wp_terms` VALUES("4","鼠绘","painter","0");
INSERT INTO `wp_terms` VALUES("6","视觉","view","0");
INSERT INTO `wp_terms` VALUES("7","Graphic","graphic","0");
INSERT INTO `wp_terms` VALUES("8","Interaction","interaction","0");
INSERT INTO `wp_terms` VALUES("9","Essay","essay","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","墨大先生");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_user-settings","libraryContent=browse&editor=tinymce&imgsize=full&hidetb=1&mfold=o");
INSERT INTO `wp_usermeta` VALUES("18","1","wp_user-settings-time","1584689734");
INSERT INTO `wp_usermeta` VALUES("19","1","wp_dashboard_quick_press_last_post_id","126");
INSERT INTO `wp_usermeta` VALUES("20","1","community-events-location","a:1:{s:2:\"ip\";s:12:\"101.227.12.0\";}");
INSERT INTO `wp_usermeta` VALUES("24","1","session_tokens","a:1:{s:64:\"565b4a5616a7ae7622d8c0ae08c652797da9cf3bb6043add12f6b61c103077e1\";a:4:{s:10:\"expiration\";i:1584862204;s:2:\"ip\";s:14:\"101.227.12.253\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36\";s:5:\"login\";i:1584689404;}}");
INSERT INTO `wp_usermeta` VALUES("25","1","wp_media_library_mode","grid");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES("1","dukechin","$P$BvtZKlhuMgEnivlmutpMVW.oy/bBqN/","dukechin","2545229027@qq.com","http://simonchen.cn","2019-11-06 08:36:36","","0","墨大先生");


